package com.example.week3_activity4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{

    Button btLogin;
    EditText etEmail, etPassword;
    String email, password;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEmail = (EditText) findViewById(R.id.etEmail);
        etPassword = (EditText) findViewById(R.id.etPassword);
        btLogin = (Button) findViewById(R.id.btLogin);

    }


    //login button method
    public void loginEvent(View view)
    {
        email = etEmail.getText().toString().trim();
        password = etPassword.getText().toString().trim();

        if(email.equals("admin") && password.equals("admin"))
        {

            //etEmail.setText("wew");
            openListViewActivity(); //call method to open ListViewActivity

        }
        else
        {

            //-----DISPLAY THAT THE INPUT IS INVALID-----
            Toast.makeText(MainActivity.this, "Invalid email or password", Toast.LENGTH_SHORT).show();

        }

    }


    //method to open ListViewActivity
    public void openListViewActivity()
    {

        Intent intent = new Intent(MainActivity.this, ListViewActivity.class);
        startActivity(intent);

    }
}