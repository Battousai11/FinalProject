package com.example.week3_activity4;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;

public class ListViewActivity extends Activity
{

    ListView lvClass;
    String[] students = {"Webster Jerome G. Villamar", "Joshua Fulgencio", "Isaac Lazaro S. Joble"};

    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);

        lvClass = (ListView) findViewById(R.id.lvClass);

        ArrayAdapter lvClassAdapter = new ArrayAdapter(ListViewActivity.this, android.R.layout.simple_list_item_1, Arrays.asList(students));
        lvClass.setAdapter(lvClassAdapter);

        Intent intent = new Intent(ListViewActivity.this, ProfileActivity.class);

        //-------to open ProfileActivity when clicked-------------
        lvClass.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {

                if(position==0)
                {

                    intent.putExtra("ivImage_value", R.drawable.image_villamar);
                    intent.putExtra("tvName_value", "Webster Jerome G. Villamar");
                    intent.putExtra("tvProgram_value", "Bachelor of Science in Information Technology");
                    intent.putExtra("tvCourse_value", "CITE 012 - Introduction to Human Computer Interaction");
                    intent.putExtra("tvBio_value", "Mafia/Gangsta4Life/BOANG/MontefalcoOxford Moments");
                    intent.putExtra("tvAge_value", "69");
                    intent.putExtra("tvHome_value", "0 LP, Hardstuck Platinum, Semi-retired, Jungle Main, Bulacan");
                    intent.putExtra("tvEmail_value", "theofficialwebster@gmail.com");
                    intent.putExtra("tvMobile_value", "+639694201337");
                    intent.putExtra("tvHobbies_value", "Gaming, Music, Daydreaming");
                    intent.putExtra("tvSocial_value", "NOT INDICATED");
                    startActivity(intent);

                }
                else if(position==1)
                {

                    intent.putExtra("ivImage_value", R.drawable.image_fulgencio);
                    intent.putExtra("tvName_value", "Joshua Fulgencio");
                    intent.putExtra("tvProgram_value", "Bachelor of Science in Information Technology");
                    intent.putExtra("tvCourse_value", "CITE 012 - Introduction to Human Computer Interaction");
                    intent.putExtra("tvBio_value", "Influencer/He/Him/Photographer|GAMER FOR LIFE|youtube.com/joshuaxd|joshuajoshua.com");
                    intent.putExtra("tvAge_value", "29");
                    intent.putExtra("tvHome_value", "999 Ford St. Dallas TX.");
                    intent.putExtra("tvEmail_value", "joshuafulgencio@yahoo.com");
                    intent.putExtra("tvMobile_value", "+63915123456");
                    intent.putExtra("tvHobbies_value", "Extroverted Activities");
                    intent.putExtra("tvSocial_value", "Facebook: Joshua xD Fulgencio\n" +
                            "\n" + "      IG: @JoshuaXD\n" +
                            "\n" + "      TikTok: @JoshuaXDD\n" +
                            "\n" + "      Mobile Legends: @JoshuaxD");
                    startActivity(intent);

                }
                else if(position==2)
                {

                    intent.putExtra("ivImage_value", R.drawable.image_joble);
                    intent.putExtra("tvName_value", "Isaac Lazaro S. Joble");
                    intent.putExtra("tvProgram_value", "Bachelor of Science in Information Technology");
                    intent.putExtra("tvCourse_value", "CITE 012 - Introduction to Human Computer Interaction");
                    intent.putExtra("tvBio_value", "NOT INDICATED");
                    intent.putExtra("tvAge_value", "20");
                    intent.putExtra("tvHome_value", "Sampaloc, Manila");
                    intent.putExtra("tvEmail_value", "cassie.jawball@ymail.com");
                    intent.putExtra("tvMobile_value", "+639087651234");
                    intent.putExtra("tvHobbies_value", "Basketball, Sleeping, Eating");
                    intent.putExtra("tvSocial_value", "Facebook: Isaac Joble\n" +
                            "\n" + "      IG: @magicpie24\n" +
                            "\n" + "      Mobile Legends: cassy");
                    startActivity(intent);

                }

            }

        });

    }

}
