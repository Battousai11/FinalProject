package com.example.week3_activity4;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity
{
    ImageView ivProfile;
    TextView tvName_value, tvProgram_value, tvCourse_value, tvBio_value, tvAge_value,
            tvHome_value, tvEmail_value, tvMobile_value, tvHobbies_value, tvSocial_value;

    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ivProfile = (ImageView) findViewById(R.id.ivProfile);
        tvName_value = (TextView) findViewById(R.id.tvName_value);
        tvProgram_value = (TextView) findViewById(R.id.tvProgram_value);
        tvCourse_value = (TextView) findViewById(R.id.tvCourse_value);
        tvBio_value = (TextView) findViewById(R.id.tvBio_value);
        tvAge_value = (TextView) findViewById(R.id.tvAge_value);
        tvHome_value = (TextView) findViewById(R.id.tvHome_value);
        tvEmail_value = (TextView) findViewById(R.id.tvEmail_value);
        tvMobile_value = (TextView) findViewById(R.id.tvMobile_value);
        tvHobbies_value = (TextView) findViewById(R.id.tvHobbies_value);
        tvSocial_value = (TextView) findViewById(R.id.tvSocial_value);

        Intent intent = getIntent();

        int intent_ivProfile_value = intent.getIntExtra("ivImage_value", R.id.ivProfile);
        ivProfile.setImageResource(intent_ivProfile_value);

        String intent_tvName_value = intent.getStringExtra("tvName_value");
        tvName_value.setText(intent_tvName_value);

        String intent_tvProgram_value = intent.getStringExtra("tvProgram_value");
        tvProgram_value.setText(intent_tvProgram_value);

        String intent_tvCourse_value = intent.getStringExtra("tvCourse_value");
        tvCourse_value.setText(intent_tvCourse_value);

        String intent_tvBio_value = intent.getStringExtra("tvBio_value");
        tvBio_value.setText(intent_tvBio_value);

        String intent_tvAge_value = intent.getStringExtra("tvAge_value");
        tvAge_value.setText(intent_tvAge_value);

        String intent_tvHome_value = intent.getStringExtra("tvHome_value");
        tvHome_value.setText(intent_tvHome_value);

        String intent_tvEmail_value = intent.getStringExtra("tvEmail_value");
        tvEmail_value.setText(intent_tvEmail_value);

        String intent_tvMobile_value = intent.getStringExtra("tvMobile_value");
        tvMobile_value.setText(intent_tvMobile_value);

        String intent_tvHobbies_value = intent.getStringExtra("tvHobbies_value");
        tvHobbies_value.setText(intent_tvHobbies_value);

        String intent_tvSocial_value = intent.getStringExtra("tvSocial_value");
        tvSocial_value.setText(intent_tvSocial_value);

    }
}
